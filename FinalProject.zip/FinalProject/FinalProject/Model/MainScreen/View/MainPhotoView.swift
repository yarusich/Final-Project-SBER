//
//  MainPhotoView.swift
//  FinalProject
//
//  Created by Антон Сафронов on 07.07.2021.
//

import UIKit

class MainPhotoView: UIView {
    
}
