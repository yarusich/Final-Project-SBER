////
////  CoreDataServiceTest.swift
////  FinalProjectTests
////
////  Created by Антон Сафронов on 30.07.2021.
////
//
//import Foundation
//
//class CoreDataServiceTest: CoreDataServiceProtocol {
//
//    var sut: CoreDataServiceProtocol!
//    var stack =
////
////    init(photoIsAdded: Bool) {
////        self.photoIsAdded = photoIsAdded
////    }
//
//    func save(photos: [PhotoDTO]) {
//        <#code#>
//    }
//
//    func delete(photos: [PhotoDTO]?) {
//        <#code#>
//    }
//
//
//}
