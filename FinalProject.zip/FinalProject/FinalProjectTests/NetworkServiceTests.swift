//
//  NetworkServiceTests.swift
//  FinalProjectUITests
//
//  Created by Антон Сафронов on 29.07.2021.
//

import XCTest

class MockNetwork: PhotoNetworkServiceProtocol {
    
    var response: GetPhotosResponse?
    var image: UIImage?

    init() {}

    convenience init (with response: GetPhotosResponse, with image: UIImage) {
        self.init()
        self.response = response
        self.image = image
    }

    func searchPhotos(currentPage page: String, searching query: String, completion: @escaping (Result<GetPhotosResponse, NetworkServiceError>) -> Void) {
        if response == nil {
            let error = NetworkServiceError.network
            completion(.failure(error))
        } else {
            guard let response = response else { return }
            completion(.success(response))
        }
    }
    
    func loadPhoto(imageUrl: String, completion: @escaping (Result<UIImage, NetworkServiceError>) -> Void) {
        if image == nil {
            let error = NetworkServiceError.network
            completion(.failure(error))
        } else {
            guard let image = image else { return }
            completion(.success(image))
        }
    }

}

class NetworkServiceTests: XCTestCase {
    
    var sut: PhotoNetworkServiceProtocol!
    let testError = NetworkServiceError.network
    var response = GetPhotosResponse(results: [PhotoDTO]())
    var image: UIImage!
    
    
    
    override func tearDown() {
        super.tearDown()
        
    }
    
    
    func testThatServiceReturnsModelData() {
        //arrange
        let model = [PhotoDTO]()
        
        let getPhotosResponse = GetPhotosResponse(results: model)
        
        let resultImage = UIImage(systemName: "heart")!
        let networkServiceMock: PhotoNetworkServiceProtocol
        networkServiceMock = NetworkServiceMock(getPhotosResponse: getPhotosResponse, resultImage: resultImage, networkCompletion: .success)
        
        let networkService = NetworkService()
        let expectationNetwork = expectation(description: "Success and network error")
        let expectationCount = resultImage
        //act
        networkServiceMock.searchPhotos { result in
            switch result {
            case
            }
            
        }
        
        //assert
    }

}
