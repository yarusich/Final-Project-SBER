//
//  Photo+CoreDataClass.swift
//  FinalProject
//
//  Created by Антон Сафронов on 23.07.2021.
//
//

import Foundation
import CoreData

@objc(Photo)
public class Photo: NSManagedObject {
    
}


