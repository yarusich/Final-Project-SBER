//
//  NetworkConstants.swift
//  FinalProject
//
//  Created by Антон Сафронов on 14.07.2021.
//

import Foundation

struct NetworkConstants {
    static let accessKey = "k4Nj9HTUUeDQIcOH5wSb8toegXMQ4Gb5tBY2ebUkt5o"
    static let baseURLString = "https://api.unsplash.com/search/photos"
//    static let sizeImageURLString = "regular"

    
}
